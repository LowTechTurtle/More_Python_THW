from distutils.core import setup

setup(name = 'ex4',
      version = '1.0',
      description = 'parse for cmd line',
      author = 'turtle',
      packages = ['ex4'],
      scripts = ['scripts/ex4_script'],
      )


